# **Dynatrace Android Gradle plugin (EAP)**

## Requirements
* Gradle version 5.0
* Android Gradle plugin version 3.1
* JRE 1.8

## Content
* folder 'libs': contains agent and plugin library
* folder 'docs': contains agent and plugin documentation
* folder 'EAPSampleApp': contains a sample project

# Preparation steps
* Read the DSL documentation (open page docs/plugin/dsl/index.html)
* Look at the sample project (use Android Studio menu entry "Import Project..." for folder "EAPSampleApp")

## How to instrument an app
1. Copy the libraries from the 'libsEAP' folder into the 'libsEAP' folder of your application module
2. Modify the build configuration (build.gradle file) of your application module
2.1. Load plugin and agent from local disk
```gradle
buildscript {
    repositories {
        flatDir {
            dirs 'libsEAP'
        }
    }
    dependencies {
        classpath 'com.dynatrace.tools.android:gradle-plugin:8.+'
    }
}

repositories {
    flatDir {
        dirs 'libsEAP'
    }
}
```
2.2. Apply plugin
```gradle
apply plugin: 'com.dynatrace.instrumentation.application'
```
2.3. Adjust build configuration. All configuration options are described in the DSL documentation
```gradle
dynatrace {
    configurations {
        sampleConfig {
            autoStart {
                applicationId '<YourApplicationID>'
                beaconUrl '<ProvidedBeaconURL>'
            }
        }
   }
}
```
3. Optional: Execute Gradle task "printVariantAffiliation" to verify that the correct variant-specific configuration is used

Windows:
```gradle
gradlew printVariantAffiliation
```
Linux:
```gradle
./gradlew printVariantAffiliation
```
4. Rebuild app. The Dynatrace Android Gradle plugin will automatically instrument the app
